//: [Previous](@previous)
print("FOR LOOP")
//example of loop

let platforms = ["iOS", "macOS", "tvOS", "iOS", "watchOS"]
for os in platforms {
    print("Swift works great on \(os).")
}

//example of a loop with a range
for i in 1...12 {
    print("5 x \(i) = \(5*i)")
}

// loops inside loops (nested loops)

for j in 1...12 {
    print ("The \(j) times table")
    for k in 1...12 {
        print ("   \(k) x \(j) is \(k*j)")
    }
   print()
}
// range from 1 through 5
for i in 1...5 {
    print("Counting from 1 through 5: \(i)")
}
print()

// range from 1 UP to 5 (useful in arrays)
for i in 1..<5 {
    print("Counting from 1 up to 5: \(i)")
}

// example of adding string in a loop + UNDERSCORE in order not to think about the name for var
var lyric = "Haters gonna"
for _ in 1...5 {
    lyric += "  hate"
}
print()

print(lyric)

let names = ["Sterling", "Cyril", "Lana", "Ray", "Pam"]

for name in names {
    print("\(name) is a secret agent")
}
print()

// usage of the loop with underscore. No variable has been used in the body of the loop
let names1 = ["Sterling", "Cyril", "Lana", "Ray", "Pam"]

for _ in names1 {
    print("[CENSORED] is a secret agent!")
}

print()
print("WHILE LOOP is not usually used and not so useful as FOR LOOP. Using to find some custom condition")
var countdown = 10
while countdown > 0 {
    print("\(countdown)...")
    countdown -= 1
}
print("Blast off! Game over")

// random + While LOOP

let id = Int.random(in: 1...1000)
let amount = Double.random(in: 0...5)

print()
var roll = 0
while roll != 10 {
    roll = Int.random(in: 1...10)
    print("I rolled a \(roll)", roll.description.count)
}
print ("Critical hit")

let colors = ["Red", "Green", "Blue", "Orange", "Yellow"]
var colorCounter = 0
while colorCounter < 5 {
    print("\(colors[colorCounter]) is a popular color.")
    colorCounter += 1
}
print()
// Skipping in the loop (continue or break)
print("Skipping in the loop (continue or break)")
let filenames = ["me.jpg", "work.txt", "sophie.jpg"]
for filename in filenames {
    if filename.hasSuffix(".jpg") == false {
        continue
    }
    print("Found pictures: \(filename)")
}

// good example of break and addition to the array
let number1 = 5
let number2 = 24
var multiples = [Int]()

for i in 1...100_000 {
    if i.isMultiple(of: number1) && i.isMultiple(of: number2) {
        multiples.append(i)
        
        if multiples.count == 10 {
            break
        }
    }
}
print(multiples)

// example of how to count results before unexpected result
print()
let scores = [1, 8, 4, 3, 0, 5, 2]
var count = 0

for score in scores {
    if score == 0 {
        break
    }

    count += 1
}

print("You had \(count) scores before you got 0.")

// example of how to count all excluding unexpected

let firstNumber = 3
let secondNumber = 5
// first type of solving

for i in 1...100 {
    if i.isMultiple(of: firstNumber) && i.isMultiple(of: secondNumber) {
        print ("FizzBuzz")
    } else if i.isMultiple(of: firstNumber) {
        print ("Fizz")
    } else if i.isMultiple(of: secondNumber) {
        print ("Buzz")
    } else {
        print ("No \(i)")
    }
}

// second type of solving
/*
for i in 1...100 {
    if i % firstNumber == 0 && i % secondNumber == 0 {
        print ("FizzBuzz")
    } else if i % firstNumber == 0 {
        print ("Fizz")
    } else if i % secondNumber == 0 {
        print ("Buzz")
    } else {
        print ("No \(i)")
    }
}

